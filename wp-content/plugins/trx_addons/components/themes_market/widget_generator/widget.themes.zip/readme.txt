Sending customer data and theme parameters to the specified e-mail
------------------------------------------------------------------

1. Extract the file "widget.themes.php" from the archive
2. Register your site on "Google reCAPTCHA 2" (https://www.google.com/recaptcha/admin#list)
   and get a pair of keys - a "public key" and "secret key"
3. "Public key" you were supposed to specify when the formation widget code on our page "Widget Generator"
4. Open file xxx and indicate at the beginning of this file the values of the variables:
   $email = 'xxx@xxxxxx.xxx';		// The email of the website owner or any other email that will receive the data from the form
   $secret_key = 'xxx';				// Secret key from Google reCAPTCHA 2
5. Place the file "widget.themes.php" to the root of your site
